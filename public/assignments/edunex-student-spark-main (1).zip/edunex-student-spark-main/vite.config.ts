// This file exists to satisfy tsconfig.node.json
// The actual config is in vite.config.js
export {}
