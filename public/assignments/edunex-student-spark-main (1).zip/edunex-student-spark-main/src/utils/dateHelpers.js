// Date utility functions
