// Form validation functions
