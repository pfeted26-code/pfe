// Role utility functions
