// Teacher route definitions
