// Admin route definitions
