// Student courses view
