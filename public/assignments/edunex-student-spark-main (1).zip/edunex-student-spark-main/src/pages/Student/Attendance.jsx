// Student attendance view
