// Admin role management component
