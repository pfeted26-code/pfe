// Admin course form component
