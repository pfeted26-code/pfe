// Student course card component
