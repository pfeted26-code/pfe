// Student grade card component
