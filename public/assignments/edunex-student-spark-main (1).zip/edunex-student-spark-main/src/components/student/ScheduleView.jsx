// Student schedule view component
