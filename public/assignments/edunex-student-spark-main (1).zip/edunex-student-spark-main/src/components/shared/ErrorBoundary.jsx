// Error boundary component
