// Shared header component
