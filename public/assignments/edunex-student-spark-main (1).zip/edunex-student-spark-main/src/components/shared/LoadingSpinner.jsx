// Loading spinner component
