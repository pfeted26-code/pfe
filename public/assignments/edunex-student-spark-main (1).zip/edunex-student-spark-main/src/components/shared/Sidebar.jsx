// Shared sidebar component
