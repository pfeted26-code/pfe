// Course management service
