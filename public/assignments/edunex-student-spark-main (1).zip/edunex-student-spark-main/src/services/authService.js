// Authentication service
