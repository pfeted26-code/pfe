// Attendance management service
