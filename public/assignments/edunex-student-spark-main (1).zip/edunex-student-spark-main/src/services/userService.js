// User management service
