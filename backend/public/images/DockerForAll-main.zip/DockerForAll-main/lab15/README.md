# **🧪 Lab 15: Delete all volumes

## 1. List volumes using the following command
```
docker volume ls
```

## 2. Delete volumes

1. Delete the volume with random name
```
docker volume rm volume_name
```

2. Delete the volumes
```
docker volume rm volumelab13 volumelab14
```