# **🧪 Lab 18: List networks

List network with the following command
```
docker network ls
```
